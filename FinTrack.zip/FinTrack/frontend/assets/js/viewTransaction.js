let allTransactions = [];
let currentPage = 1;
const itemsPerPage = 15;

console.log("✅ view-transactions.js loaded");


const token = localStorage.getItem("token");
if (!token) {
    window.location.href = "login.html";
}

function formatCurrency(amount) {
    if (isNaN(amount)) return "₹0";
    return `₹${Number(amount).toLocaleString("en-IN")}`;
}

function showToast(message, type = "success") {
    const toast = document.getElementById("toast");
    const toastMessage = document.getElementById("toastMessage");
    const toastIcon = document.getElementById("toastIcon");
    const toastClose = document.getElementById("toastClose");

    toastMessage.textContent = message;
    toastIcon.textContent = type === "success" ? "✅" :
        type === "error" ? "❌" :
            type === "info" ? "ℹ️" : "";

    toast.className = `toast show ${type}`;
    const hide = () => toast.className = "toast hidden";
    toastClose.onclick = hide;
    setTimeout(hide, 3000);
}

document.addEventListener("DOMContentLoaded", () => {
    fetchAndRenderTransactions();

    document.getElementById("searchInput").addEventListener("input", () => {
        currentPage = 1;
        fetchAndRenderTransactions();
    });

    document.getElementById("fromDate").addEventListener("change", () => {
        currentPage = 1;
        fetchAndRenderTransactions();
    });

    document.getElementById("toDate").addEventListener("change", () => {
        currentPage = 1;
        fetchAndRenderTransactions();
    });

    document.getElementById("transactionForm")?.addEventListener("submit", async function (e) {
        e.preventDefault();

        const type = document.getElementById("type").value;
        const category = document.getElementById("category").value;
        const amount = document.getElementById("amount").value;
        const description = document.getElementById("description").value;

        if (!type || !category || !amount || !description) {
            showToast("Please fill all fields", "error");
            return;
        }

        const data = { type, category, amount, description };

        try {
            const res = await fetch("http://localhost:3002/api/transactions", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    Authorization: `Bearer ${token}`
                },
                body: JSON.stringify(data)
            });

            if (!res.ok) throw new Error("Failed to add transaction");

            showToast("Transaction added successfully", "success");
            document.getElementById("transactionForm").reset();
            document.querySelector("#typeDropdown .selected").textContent = "Select Type";
            document.querySelector("#categoryDropdown .selected").textContent = "Select Category";
            document.getElementById("type").value = "";
            document.getElementById("category").value = "";

            fetchAndRenderTransactions();

        } catch (err) {
            console.error(err);
            showToast("Failed to add transaction", "error");
        }
    });



});

async function fetchAndRenderTransactions() {
    try {
        const res = await fetch("http://localhost:3002/api/transactions", {
            headers: { Authorization: `Bearer ${token}` }
        });
        if (!res.ok) {
            const error = await res.json();
            console.error("❌ API Error:", error);
            showToast(errData.message || "Failed to load", "error");
            return;
        }
        const { transactions } = await res.json();

        allTransactions = transactions;

        const filtered = applyFilters(transactions);

        filtered.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

        const paginated = paginate(filtered, currentPage);
        renderTransactions(paginated);
        renderPagination(filtered.length);
    } catch (err) {
        console.error("Error fetching transactions", err);
    }
}

function applyFilters(data) {
    const search = document.getElementById("searchInput")?.value?.toLowerCase() || "";
    const fromDate = document.getElementById("fromDate")?.value;
    const toDate = document.getElementById("toDate")?.value;

    return data.filter(t => {
        const matchesSearch = t.description.toLowerCase().includes(search)
            || t.type.toLowerCase().includes(search)
            || t.category.toLowerCase().includes(search);

        const createdDate = new Date(t.createdAt);
        const from = fromDate ? new Date(fromDate) : null;
        const to = toDate ? new Date(toDate + "T23:59:59") : null;

        const withinFrom = from ? createdDate >= from : true;
        const withinTo = to ? createdDate <= to : true;

        return matchesSearch && withinFrom && withinTo;
    });
}

function paginate(array, page = 1, limit = itemsPerPage) {
    const start = (page - 1) * limit;
    return array.slice(start, start + limit);
}

function renderTransactions(transactions) {
    const container = document.getElementById("transactionList");
    if (!container) return;
    container.innerHTML = "";

    transactions.forEach(t => {
        const item = document.createElement("div");
        item.className = `transaction-item ${t.type}`;

        item.innerHTML = `
      <div class="t-type">${t.type.charAt(0).toUpperCase() + t.type.slice(1)}</div>
      <div class="t-category"><em>${t.category}</em></div>
      <div class="t-description">
        <div>${t.description}</div>
        <small>${new Date(t.createdAt).toLocaleDateString("en-GB")}</small>
      </div>
      <div class="t-amount ${t.type}">
        ${t.type === 'income' ? '+' : '-'}${formatCurrency(t.amount)}
      </div>
      <div class="t-actions">
        <button class="edit-btn" onclick="editTransaction('${t._id}')">✏️</button>
        <button class="delete-btn" onclick="deleteTransaction('${t._id}')">🗑️</button>
      </div>
    `;

        container.appendChild(item);
    });
}

function renderPagination(totalItems) {
    const totalPages = Math.ceil(totalItems / itemsPerPage);
    const container = document.getElementById("pagination");
    container.innerHTML = "";

    if (currentPage > 1) {
        const prev = document.createElement("button");
        prev.textContent = "⬅️";
        prev.onclick = () => {
            currentPage--;
            fetchAndRenderTransactions();
        };
        container.appendChild(prev);
    }

    for (let i = 1; i <= totalPages; i++) {
        const btn = document.createElement("button");
        btn.textContent = i;
        btn.className = i === currentPage ? "active" : "";
        btn.onclick = () => {
            currentPage = i;
            fetchAndRenderTransactions();
        };
        container.appendChild(btn);
    }

    if (currentPage < totalPages) {
        const next = document.createElement("button");
        next.textContent = "➡️";
        next.onclick = () => {
            currentPage++;
            fetchAndRenderTransactions();
        };
        container.appendChild(next);
    }
}

window.deleteTransaction = async function (id) {
    if (!confirm("Are you sure you want to delete this transaction?")) return;

    try {
        const res = await fetch(`http://localhost:3002/api/transactions/${id}`, {
            method: "DELETE",
            headers: { Authorization: `Bearer ${token}` }
        });

        if (!res.ok) throw new Error("Failed");

        showToast("Transaction deleted", "error");
        fetchAndRenderTransactions();
    } catch (err) {
        showToast("Error deleting", "error");
    }
};

window.editTransaction = function (id) {
    const tx = allTransactions.find(t => t._id === id);
    if (!tx) return showToast("Transaction not found", "error");

    document.getElementById("editId").value = tx._id;
    document.getElementById("editType").value = tx.type;
    document.getElementById("editCategory").value = tx.category;
    document.getElementById("editAmount").value = tx.amount;
    document.getElementById("editDescription").value = tx.description;

    document.getElementById("editModal").classList.remove("hidden");
};

document.getElementById("editTransactionForm")?.addEventListener("submit", async function (e) {
    e.preventDefault();
    const id = document.getElementById("editId").value;
    const data = {
        type: document.getElementById("editType").value,
        category: document.getElementById("editCategory").value,
        amount: document.getElementById("editAmount").value,
        description: document.getElementById("editDescription").value,
    };

    try {
        const res = await fetch(`http://localhost:3002/api/transactions/${id}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
                Authorization: `Bearer ${token}`
            },
            body: JSON.stringify(data)
        });

        if (!res.ok) throw new Error("Update failed");

        document.getElementById("editModal").classList.add("hidden");
        showToast("Updated successfully", "success");
        fetchAndRenderTransactions();
    } catch (err) {
        showToast("Error updating", "error");
    }
});

document.getElementById("closeEditModal")?.addEventListener("click", () => {
    document.getElementById("editModal").classList.add("hidden");
});

document.querySelectorAll('.custom-dropdown').forEach(drop => {
    const selected = drop.querySelector('.selected');
    const options = drop.querySelector('.dropdown-options');
    const hiddenInput = drop.querySelector('input[type="hidden"]') || document.getElementById(drop.id.replace('Dropdown', ''));

    selected.addEventListener('click', () => {
        drop.classList.toggle('active');
    });

    options.querySelectorAll('li').forEach(option => {
        option.addEventListener('click', () => {
            selected.textContent = option.textContent;
            hiddenInput.value = option.getAttribute('data-value');
            drop.classList.remove('active');

            if (drop.id === "typeDropdown") {
                updateCategoryDropdown(option.getAttribute('data-value')); // 👇 defined below
            }
        });
    });
});

function updateCategoryDropdown(type) {
    const categories = {
        income: ["Salary", "Business", "Investment", "Other"],
        expense: ["Food", "Rent", "Transport", "Shopping", "Other"]
    };

    const catOptions = document.getElementById("categoryOptions");
    catOptions.innerHTML = ""; // Clear existing

    categories[type].forEach(cat => {
        const li = document.createElement("li");
        li.textContent = cat;
        li.setAttribute("data-value", cat);
        li.addEventListener("click", () => {
            document.querySelector("#categoryDropdown .selected").textContent = cat;
            document.getElementById("category").value = cat;
            document.getElementById("categoryDropdown").classList.remove("active");
        });
        catOptions.appendChild(li);
    });

    // Reset display text
    document.querySelector("#categoryDropdown .selected").textContent = "Select Category";
    document.getElementById("category").value = "";
}
