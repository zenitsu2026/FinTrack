const token = localStorage.getItem("token");
if (!token) {
  window.location.href = "login.html";
}

function showToast(message, type = "success") {
  const toast = document.getElementById("toast");
  const messageEl = document.getElementById("toastMessage");
  const icon = document.getElementById("toastIcon");

  messageEl.textContent = message;
  icon.textContent = type === "success" ? "✅" : "❌";
  toast.className = `toast show ${type}`;

  setTimeout(() => {
    toast.className = "toast hidden";
  }, 3000);

  document.getElementById("toastClose").onclick = () => {
    toast.className = "toast hidden";
  };
}

async function fetchProfile() {
  try {
    const res = await fetch("http://localhost:3002/api/profile", {
      headers: {
        Authorization: `Bearer ${token}`,
      },
    });

    const data = await res.json();
    document.getElementById("profileName").textContent = data.name || "User";
    document.getElementById("profileEmail").textContent = data.email || "";
  } catch (err) {
    showToast("Failed to load profile", "error");
  }
}

document.getElementById("logoutBtn").addEventListener("click", () => {
  localStorage.removeItem("token");
  window.location.href = "login.html";
});

document.getElementById("updateProfileForm").addEventListener("submit", async (e) => {
  e.preventDefault();

  const newName = document.getElementById("newName").value.trim();
  const currentPassword = document.getElementById("currentPassword").value.trim();
  const newPassword = document.getElementById("newPassword").value.trim();

  if (!newName && (!currentPassword || !newPassword)) {
    showToast("Please provide a new name or password details", "error");
    return;
  }

  // 🔁 Update Name
  if (newName) {
    try {
      const res = await fetch("http://localhost:3002/api/profile/update-name", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ name: newName }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      showToast("Name updated successfully!", "success");
    } catch (err) {
      showToast(err.message || "Failed to update name", "error");
    }
  }

  // 🔁 Update Password
  if (currentPassword && newPassword) {
    try {
      const res = await fetch("http://localhost:3002/api/profile/update-password", {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${token}`,
        },
        body: JSON.stringify({ currentPassword, newPassword }),
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.message);
      showToast("Password updated successfully!", "success");
    } catch (err) {
      showToast(err.message || "Failed to update password", "error");
    }
  }

  // Clear form
  document.getElementById("newName").value = "";
  document.getElementById("currentPassword").value = "";
  document.getElementById("newPassword").value = "";

  // Refresh profile data
  fetchProfile();
});

// Initial fetch
fetchProfile();
