document.addEventListener("DOMContentLoaded", function () {
    const token = localStorage.getItem("token");
    if (!token) return location.href = "login.html";

    function formatCurrency(amount) {
        return `₹${Number(amount).toLocaleString("en-IN")}`;
    }

    const logoutBtn = document.getElementById("logoutBtn");
    if (logoutBtn) {
        logoutBtn.addEventListener("click", () => {
            localStorage.removeItem("token");
            window.location.href = "login.html";
        });
    }


    async function fetchTransactions() {
        try {
            const res = await fetch("http://localhost:3002/api/transactions", {
                headers: { Authorization: `Bearer ${token}` },
            });
            const { transactions } = await res.json();

            renderSummary(transactions);
            renderCategoryChart(transactions);
            renderTrendChart(transactions);
            renderSmartSuggestions(transactions);
        } catch (err) {
            console.error("Error fetching data", err);
        }
    }

    function renderSummary(transactions) {
        let income = 0, expense = 0;

        transactions.forEach(t => {
            if (t.type === "income") income += Number(t.amount);
            else if (t.type === "expense") expense += Number(t.amount);
        });

        const incomeEl = document.getElementById("totalIncome");
        const expenseEl = document.getElementById("totalExpense");
        const balanceEl = document.getElementById("totalBalance");

        if (incomeEl) incomeEl.textContent = formatCurrency(income);
        if (expenseEl) expenseEl.textContent = formatCurrency(expense);
        if (balanceEl) balanceEl.textContent = formatCurrency(income - expense);
    }


    function renderCategoryChart(transactions) {
        const ctx = document.getElementById("categoryChart")?.getContext("2d");
        if (!ctx) return;

        const expenses = transactions.filter(t => t.type === "expense");

        const categoryTotals = expenses.reduce((acc, t) => {
            acc[t.category] = (acc[t.category] || 0) + Number(t.amount);
            return acc;
        }, {});

        const data = {
            labels: Object.keys(categoryTotals),
            datasets: [{
                label: 'Expenses',
                data: Object.values(categoryTotals),
                backgroundColor: ['#e74c3c', '#f39c12', '#2ecc71', '#3498db', '#9b59b6']
            }]
        };

        if (window.categoryChartInstance) window.categoryChartInstance.destroy();
        window.categoryChartInstance = new Chart(ctx, {
            type: 'pie',
            data: data
        });
    }

    function renderTrendChart(transactions) {
        const ctx = document.getElementById("trendChart").getContext("2d");
        const monthlyTotals = {};

        transactions.forEach(t => {
            const date = new Date(t.createdAt);
            const key = `${date.getFullYear()}-${String(date.getMonth() + 1).padStart(2, '0')}`;
            if (!monthlyTotals[key]) monthlyTotals[key] = { income: 0, expense: 0 };
            monthlyTotals[key][t.type] += Number(t.amount);
        });

        const labels = Object.keys(monthlyTotals);
        const incomeData = labels.map(k => monthlyTotals[k].income);
        const expenseData = labels.map(k => monthlyTotals[k].expense);

        const data = {
            labels,
            datasets: [
                {
                    label: 'Income',
                    data: incomeData,
                    borderColor: 'green',
                    backgroundColor: 'rgba(0,128,0,0.2)',
                    tension: 0.3
                },
                {
                    label: 'Expense',
                    data: expenseData,
                    borderColor: 'red',
                    backgroundColor: 'rgba(255,0,0,0.2)',
                    tension: 0.3
                }
            ]
        };

        if (window.trendChartInstance) window.trendChartInstance.destroy();
        window.trendChartInstance = new Chart(ctx, {
            type: 'line',
            data: data
        });
    }

    function renderSmartSuggestions(transactions) {
        const ul = document.getElementById("smartSuggestions");
        ul.innerHTML = "";

        const income = transactions.filter(t => t.type === "income")
            .reduce((a, b) => a + Number(b.amount), 0);
        const expense = transactions.filter(t => t.type === "expense")
            .reduce((a, b) => a + Number(b.amount), 0);
        const balance = income - expense;

        const categoryTotals = transactions
            .filter(t => t.type === "expense")
            .reduce((acc, t) => {
                acc[t.category] = (acc[t.category] || 0) + Number(t.amount);
                return acc;
            }, {});

        const topCategory = Object.entries(categoryTotals)
            .sort((a, b) => b[1] - a[1])[0];

        const suggestions = [
            expense < income
                ? "✅ Great job! You're spending within limits."
                : "⚠️ Warning: Spending exceeds income. Review expenses.",
            topCategory ? `📌 Top spending category: <b>${topCategory[0]}</b> ₹${formatCurrency(topCategory[1])}` : "",
            `💰 Monthly Savings: ₹${formatCurrency(balance)}`
        ];

        suggestions.forEach(s => {
            const li = document.createElement("li");
            li.innerHTML = s;
            ul.appendChild(li);
        });
    }

    fetchTransactions();
});

