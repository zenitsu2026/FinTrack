const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");
const path = require("path");
const dotenv = require("dotenv");

dotenv.config();

const app = express();

// Middleware
app.use(cors());
app.use(express.json());

// --- Serve static frontend files ---
const frontendPath = path.join(__dirname, "..", "frontend");
app.use(express.static(frontendPath));

// --- Auth API routes ---
const authRoutes = require("./routes/authRoutes");
const profileRoutes = require("./routes/profileRoutes");

app.use("/api/auth", authRoutes);
app.use("/api/profile", profileRoutes);


// --- Fallback for HTML page routes ---
app.get("/", (req, res) => {
  res.sendFile(path.join(frontendPath, "pages", "index.html"));
});

app.get("/login.html", (req, res) => {
  res.sendFile(path.join(frontendPath, "pages", "login.html"));
});

app.get("/register.html", (req, res) => {
  res.sendFile(path.join(frontendPath, "pages", "register.html"));
});

//dashboard
app.get("/dashboard.html", (req, res) => {
  res.sendFile(path.join(__dirname, "..", "frontend", "pages", "dashboard.html"));
});

const transactionRoutes = require("./routes/transactionRoutes");
app.use("/api/transactions", transactionRoutes);




// --- Start server ---
const PORT = process.env.PORT || 3002;
mongoose.connect(process.env.MONGO_URI, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
}).then(() => {
  console.log("✅ MongoDB Connected");
  app.listen(PORT, () => {
    console.log(`🚀 Server running at http://localhost:${PORT}`);
  });
}).catch((err) => {
  console.error("❌ MongoDB connection error:", err);
});

