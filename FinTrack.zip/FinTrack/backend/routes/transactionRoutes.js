const express = require("express");
const router = express.Router();
const Transaction = require("../models/Transaction");
const authMiddleware = require("../middleware/authMiddleware"); // ✅ Import correct middleware
const User = require("../models/User");



router.post("/", authMiddleware, async (req, res) => {
    try {
        const { amount, description, category, type } = req.body;
        const transaction = await Transaction.create({
            user: req.user._id, // ✅ Correct way to access user ID
            amount,
            description,
            category,
            type,
        });

        res.status(201).json({ message: "Transaction added successfully", transaction });
    } catch (err) {
        res.status(500).json({ message: "Error saving transaction", error: err.message });
    }
});

router.get("/", authMiddleware, async (req, res) => {
    try {
        const transactions = await Transaction.find({ user: req.user._id }).sort({ createdAt: -1 });
        res.status(200).json({ transactions });
    } catch (err) {
        res.status(500).json({ message: "Failed to fetch transactions", error: err.message });
    }
});

router.put('/:id', authMiddleware, async (req, res) => {
    try {
        const updated = await Transaction.findOneAndUpdate(
            { _id: req.params.id, user: req.user._id },
            req.body,
            { new: true }
        );

        if (!updated) return res.status(404).json({ message: "Transaction not found" });
        res.json({ message: "Transaction updated", transaction: updated });
    } catch (err) {
        res.status(500).json({ message: "Update failed", error: err.message });
    }
});

router.delete('/:id', authMiddleware, async (req, res) => {
    try {
        const deleted = await Transaction.findOneAndDelete({ _id: req.params.id, user: req.user._id });
        if (!deleted) return res.status(404).json({ message: "Transaction not found" });

        res.json({ message: "Transaction deleted" });
    } catch (err) {
        res.status(500).json({ message: "Delete failed", error: err.message });
    }
});



module.exports = router;
