const express = require("express");
const router = express.Router();
const authMiddleware = require("../middleware/authMiddleware");
const {
  getProfile,
  updateName,
  updatePassword,
} = require("../controllers/profileController");

// 🔐 Get user profile
router.get("/", authMiddleware, getProfile);

// ✏️ Update name
router.put("/update-name", authMiddleware, updateName);

// 🔐 Update password
router.put("/update-password", authMiddleware, updatePassword);

module.exports = router;
