exports.addTransaction = async (req, res) => {
  try {
    const { amount, description, category, type } = req.body;
    const userId = req.user.userId;

    if (!amount || !description || !category || !type) {
      return res.status(400).json({ message: "All fields are required" });
    }

    const newTx = await Transaction.create({
      userId,
      amount,
      description,
      category,
      type,
    });

    res.status(201).json({ message: "Transaction added", transaction: newTx });
  } catch (err) {
    console.error("❌ Add Transaction Error:", err);
    res.status(500).json({ message: "Server error" });
  }
};
